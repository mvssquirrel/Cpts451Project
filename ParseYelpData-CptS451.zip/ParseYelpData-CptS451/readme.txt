Instructions for Compiling and Running "parse_yelp":

1. Download and extract Yelp JSON files
Copy the datafiles to a folder.  
2. Edit Parser.cs and set the "dataDir" path to the folder that you copied the JSON files in step 1.  
3. The output files will be creted under "dataDir".